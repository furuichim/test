﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenCvSharp.Text;
using OpenCvSharp;

namespace TextDetectionTest
{
    class Program
    {

        /// <summary>
        /// https://stackoverflow.com/questions/23506105/extracting-text-opencv
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine(args[0]);
            // オリジナル画像を読み込む
            Mat src = Cv2.ImRead(args[0]);

            // 相似比0.5で縮小する
            Mat small = new Mat();
            do
            {
                Cv2.PyrDown(src, small);
                src = small;
            } while (small.Width > 2048);

            // グレースケールにする
            Mat gray = new Mat();
            Cv2.CvtColor(small, gray, ColorConversionCodes.BGR2GRAY);

            // モルフォロジー変換する
            Mat grad = new Mat();
            Mat morphKernel = Cv2.GetStructuringElement(MorphShapes.Ellipse, new Size(5, 5));
            Cv2.MorphologyEx(gray, grad, MorphTypes.Gradient, morphKernel);

            // 二値化する
            Mat bw = new Mat();
            Cv2.Threshold(grad, bw, 0.0, 255.0, ThresholdTypes.Binary | ThresholdTypes.Otsu);

            // 水平方向に結合する
            Mat connected = new Mat();
            morphKernel = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(10, 5));
            //morphKernel = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(20, 5));
            Cv2.MorphologyEx(bw, connected, MorphTypes.Close, morphKernel);

            // 塊を探す
            Mat mask = Mat.Zeros(bw.Size(), MatType.CV_8UC1);
            Point[][] contours;
            HierarchyIndex[] hierarchy;
            Cv2.FindContours(connected, out contours, out hierarchy, RetrievalModes.CComp, ContourApproximationModes.ApproxSimple, new Point(0, 0));

            //OCRTesseract ocr = OCRTesseract.Create();
            for (int idx = 0; idx >= 0; idx = hierarchy[idx].Next)
            {
                // 領域サイズに合わせたマスクを作成する
                Rect rect = Cv2.BoundingRect(contours[idx]);
                Mat maskROI = new Mat(mask, rect);

                // マスクにContourを描画する
                Cv2.DrawContours(mask, contours, idx, new Scalar(255, 255, 255), -1);

                double r = (double)Cv2.CountNonZero(maskROI) / (rect.Width * rect.Height);

                if (r > .45 /* assume at least 45% of the area is filled if it contains text */
                    &&
                    (rect.Width > 8 && rect.Height > 8) /* constraints on region size */
                    /* these two conditions alone are not very robust. better to use something 
                    like the number of significant peaks in a horizontal projection as a third condition */
                    )
                {
                    Cv2.Rectangle(small, rect, new Scalar(0, 255, 0), 2);

                    //Mat target = new Mat(small, rect);
                    //String text;
                    //Rect[] rects;
                    //String[] ts;
                    //float[] confidences;
                    ////ocr.Run(target, out text, out rects, out ts, out confidences);
                    //Console.WriteLine(text);
                }
            }

            small.ImWrite("c:\\temp\\test.png");
        }
    }
}
